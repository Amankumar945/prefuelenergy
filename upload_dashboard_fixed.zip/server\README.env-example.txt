# Server environment example
# Copy to `server/.env` or export before running in production

PORT=5000
JWT_SECRET=change_me_in_production
CORS_ORIGIN=http://localhost:5173
